# members-only
Odin project - Node JS - members only

This is a forum with 3 types of access modes - normal mode, special user and admin mode. Normal users cannot see name and date of posts but special users can. Admin users can see delete messages.

Objectives:
* made express app using express-generator
* used dotenv to secure database url.
* used express-validator to sanitize inputs
* used MVC model
* used passport.js to login
* used bcryptjs to encrypt passwords

